import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

# Read data
file = Path(__file__).with_name("E0_L4_VTC FOR PYTHON.txt")
data = pd.read_csv(file, sep="\t")

# Clean column names
data.columns = data.columns.str.strip()

# Extract values
VIN = data["VIN"].to_numpy()
VOUT = data["V(vout)"].to_numpy()

VDD = 5.0
HALF_VDD = VDD / 2

# Find where VOUT crosses VDD/2
difference = VOUT - HALF_VDD
crossings = np.where(difference[:-1] * difference[1:] <= 0)[0]

if len(crossings) == 0:
    raise ValueError("VOUT does not cross 2.5 V. Check the input data.")

# Linear interpolation at the first crossing
i = crossings[0]

Vm = VIN[i] + (
    (HALF_VDD - VOUT[i]) *
    (VIN[i + 1] - VIN[i]) /
    (VOUT[i + 1] - VOUT[i])
)

# Plot VTC
plt.figure(figsize=(9, 6))
plt.plot(VIN, VOUT, color="blue", linewidth=2, label="Discrete CMOS Inverter")

plt.axhline(HALF_VDD, color="red", linestyle=":", label="VDD/2 = 2.5 V")
plt.axvline(Vm, color="green", linestyle="--", label=f"Vm = {Vm:.3f} V")
plt.plot(Vm, HALF_VDD, "ko", label="Switching point")

plt.xlabel("Input Voltage VIN (V)")
plt.ylabel("Output Voltage VOUT (V)")
plt.title("Voltage Transfer Characteristic - Discrete CMOS Inverter")

plt.xlim(0, VDD)
plt.ylim(0, VDD)
plt.grid(True)
plt.legend()
plt.tight_layout()

plt.savefig("L4_VTC.png", dpi=300)
plt.show()

print(f"Switching threshold Vm = {Vm:.4f} V")