import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

# Folder containing the Python script and data files
folder = Path(__file__).parent

# Read LTspice data
discrete = pd.read_csv(
    folder / "E0_L4_VTC FOR PYTHON.txt",
    sep=r"\s+"
)

nm65 = pd.read_csv(
    folder / "vtc_65nm.txt",
    sep=r"\s+"
)

# Supply voltages
VDD_discrete = 5.0
VDD_65nm = 1.0

# Extract discrete CMOS data
VIN_discrete = discrete["VIN"]
VOUT_discrete = discrete["V(vout)"]

# Extract 65 nm CMOS data
VIN_65nm = nm65["VIN"]
VOUT_65nm = nm65["V(out)"]

# Normalise both datasets
VIN_discrete_norm = VIN_discrete / VDD_discrete
VOUT_discrete_norm = VOUT_discrete / VDD_discrete

VIN_65nm_norm = VIN_65nm / VDD_65nm
VOUT_65nm_norm = VOUT_65nm / VDD_65nm

# Plot normalised VTC
plt.figure(figsize=(9, 6))

plt.plot(
    VIN_discrete_norm,
    VOUT_discrete_norm,
    linewidth=2,
    label="Discrete CMOS Inverter"
)

plt.plot(
    VIN_65nm_norm,
    VOUT_65nm_norm,
    linewidth=2,
    label="65 nm CMOS Inverter"
)

# Graph formatting
plt.xlabel("Normalised Input Voltage (VIN/VDD)")
plt.ylabel("Normalised Output Voltage (VOUT/VDD)")
plt.title("Normalised VTC Comparison")

plt.xlim(0, 1)
plt.ylim(0, 1)

plt.grid(True)
plt.legend()
plt.tight_layout()

# Save and display
plt.savefig(folder / "L5_VTC_Comparison.png", dpi=300)
plt.show()

print("Normalised VTC comparison completed successfully.")